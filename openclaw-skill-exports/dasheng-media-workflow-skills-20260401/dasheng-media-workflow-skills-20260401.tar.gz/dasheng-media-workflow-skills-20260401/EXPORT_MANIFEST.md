# Dasheng Media Workflow Skills Export (2026-04-01)

## 包含技能

- `dasheng-sop-orchestrator`
- `dasheng-stage-intake-brief-draft`
- `dasheng-stage-material-refill`
- `dasheng-stage-rewrite`
- `dasheng-stage-publish-video`

## 默认工作区

- 主工作区：`/Volumes/PSSD/Projects/公众号文章`
- 动画图表工程：`/Volumes/PSSD/Projects/finance-motion-8787`
- 可通过环境变量覆盖：
  - `DASHENG_WORKSPACE`
  - `FINANCE_MOTION_WORKSPACE`

## 导入方式（龙虾/OpenClaw）

1. 复制 `skills/*` 到你的 skill 目录（例如 `~/.openclaw/skills`）。
2. 如工作区路径不同，修改每个 `SKILL.md` 中的默认路径或设置环境变量。
3. 验证入口技能：
   - `dasheng-sop-orchestrator`

## 当前口径

- 主链：`intake -> brief -> draft -> material -> rewrite -> publish -> postmortem`
- `publish` 阶段已包含：
  - 互动图表视频（CSV -> finance-motion-8787 -> webm/mp4）
  - motion 叙事视频（改写稿 -> 场景 -> webm/mp4）

