# Dasheng SOP Skills Export (Sanitized)

## Export time
- 2026-03-22

## Included skills
- dasheng-brief-builder
- dasheng-caiji
- dasheng-clustering
- dasheng-collection-workflow (empty placeholder)
- dasheng-daily-brief
- dasheng-daily-clustering
- dasheng-daily-draft
- dasheng-daily-final
- dasheng-daily-intake
- dasheng-daily-material
- dasheng-daily-outline
- dasheng-daily-phase2
- dasheng-daily-postmortem
- dasheng-daily-shared
- dasheng-intake-brief-prod
- dasheng-xuanti
- dasheng-xuanti-skill (from ~/.openclaw/skills)

## Sanitization applied
- Removed runtime data and historical run artifacts (`runtime-data/`, `runs/`, `artifacts/`).
- Replaced sensitive config fields with `<REPLACE_ME>`.
- Rewrote machine-specific absolute paths from `/Users/lichengyin/clawd` to `${OPENCLAW_WORKSPACE}`.

## Migration steps
1. Copy `skills/` into your target project skill root.
2. Search for `<REPLACE_ME>` and fill actual values:
   - chat/group IDs
   - token/secret fields
3. Ensure `${OPENCLAW_WORKSPACE}` is mapped to your real workspace path.
4. Run local dry-run for each entry skill:
   - `dasheng-daily-intake`
   - `dasheng-daily-clustering`
   - `dasheng-daily-brief`
