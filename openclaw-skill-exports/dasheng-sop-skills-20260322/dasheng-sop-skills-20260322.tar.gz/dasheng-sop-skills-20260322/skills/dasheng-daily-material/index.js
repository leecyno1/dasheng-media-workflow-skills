#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const {
  nowIso,
  readJsonIfExists,
  writeJson,
  sha1,
  markStepCompleted,
  markStepFailed,
  finishManifest
} = require('../dasheng-daily-shared/runtime/manifest');
const {
  persistArtifact,
  appendArtifactRef
} = require('../dasheng-daily-shared/runtime/artifact-store');

const SHARED_DIR = path.join(__dirname, '..', 'dasheng-daily-shared');
const RUNTIME_DIR = path.join(SHARED_DIR, 'runtime-data');

async function supplementMaterial(contentBriefsFile, options = {}) {
  let manifest;
  let manifestFile;

  try {
    const briefsFile = contentBriefsFile || options.content_briefs_file;
    if (!briefsFile || !fs.existsSync(briefsFile)) {
      throw new Error('缺少 content_briefs_file');
    }

    const briefs = JSON.parse(fs.readFileSync(briefsFile, 'utf8'));
    const runId = options.run_id || briefs?.[0]?.meta?.run_id;
    if (!runId) throw new Error('无法从 ContentBrief 推断 run_id');

    manifestFile = path.join(RUNTIME_DIR, 'runs', runId, 'run_manifest.json');
    manifest = readJsonIfExists(manifestFile);
    if (!manifest) throw new Error(`manifest 不存在: ${manifestFile}`);

    console.log(`[material] 开始补充素材 run_id=${runId}`);

    const materialPacks = briefs.map(brief => buildMaterialPack(brief, runId));
    const resultFile = persistArtifact({
      baseDir: RUNTIME_DIR,
      runId,
      step: 'material',
      name: 'material-packs.json',
      data: materialPacks
    });

    manifest = appendArtifactRef(manifest, {
      step: 'material',
      object_type: 'MaterialPack',
      count: materialPacks.length,
      file: resultFile,
      doc_url: null
    });

    manifest = markStepCompleted(manifest, 'material');
    manifest.current_step = 'outline';
    manifest = finishManifest(manifest);
    writeJson(manifestFile, manifest);

    console.log(`[material] 完成，共 ${materialPacks.length} 个素材包`);
    return {
      success: true,
      run_id: runId,
      total_packs: materialPacks.length,
      material_packs_file: resultFile,
      manifest_file: manifestFile,
      next_step: 'dasheng-daily-outline'
    };
  } catch (error) {
    if (manifest && manifestFile) {
      manifest = markStepFailed(manifest, 'material', error.message);
      writeJson(manifestFile, manifest);
    }
    console.error('[material] 错误:', error.message);
    throw error;
  }
}

function buildMaterialPack(brief, runId) {
  const createdAt = nowIso();
  return {
    meta: {
      id: `${runId}:material:${brief.meta.id.split(':').pop()}`,
      object_type: 'MaterialPack',
      run_id: runId,
      version: '3.0.0',
      status: 'ready',
      generated_by: 'dasheng-daily-material',
      input_digest: sha1(brief.meta.id + brief.title),
      upstream_ids: [brief.meta.id],
      doc_refs: [],
      created_at: createdAt,
      updated_at: createdAt
    },
    topic_id: brief.topic_id,
    title: brief.title,
    materials: {
      images: generateImages(brief),
      videos: generateVideos(brief),
      quotes: generateQuotes(brief),
      data_points: generateDataPoints(brief),
      references: generateReferences(brief)
    },
    coverage_notes: [
      `已覆盖主张：${brief.core_claim}`,
      `建议媒介：${(brief.recommended_media || []).join(', ')}`
    ],
    gaps: [
      '缺少真实外部引用抓取',
      '缺少原始截图/图表素材',
      '缺少可直接复用的一手数据源'
    ]
  };
}

function generateImages(brief) {
  return [
    { title: `${brief.title} 配图 1`, hint: '趋势图/截图', source_type: 'placeholder' },
    { title: `${brief.title} 配图 2`, hint: '人物/场景图', source_type: 'placeholder' }
  ];
}

function generateVideos(brief) {
  return [
    { title: `${brief.title} 视频素材`, hint: '短视频切片或讲解镜头', source_type: 'placeholder' }
  ];
}

function generateQuotes(brief) {
  return [
    { text: brief.core_claim, source: 'brief.core_claim' },
    { text: (brief.risk_notes || [])[0] || '待补充引用', source: 'brief.risk_notes' }
  ];
}

function generateDataPoints(brief) {
  return [
    { label: 'article_value', value: brief.scorecard.article_value },
    { label: 'viral_potential', value: brief.scorecard.viral_potential },
    { label: 'composite', value: brief.scorecard.composite }
  ];
}

function generateReferences(brief) {
  return (brief.evidence_requirements || []).map((item, idx) => ({
    title: `evidence_requirement_${idx + 1}`,
    note: item,
    source_type: 'brief_requirement'
  }));
}

if (require.main === module) {
  const contentBriefsFile = process.argv[2];
  supplementMaterial(contentBriefsFile).then(() => process.exit(0)).catch(() => process.exit(1));
}

module.exports = { supplementMaterial, buildMaterialPack };
