---
name: dasheng-daily-phase2
description: 大圣自媒体工作流第二环节技能。无缝接收 `dasheng-daily-intake` 产出的底稿（约1000条 IntakeRecord 或 v11 采集输出），执行主题聚类、热度评估、证据链整理与强化版 Brief 生成。用于“重跑第二环节”“生成最新 Brief 库”“给编辑可执行选题建议”场景。
---

# dasheng-daily-phase2

## 目标

把第一环节底稿转换为可执行的编辑决策资产：

1. 主题聚类索引
2. 话题热度分析
3. 多维证据链（跨平台）
4. 撰写建议（角度/标题/结构/风险）
5. TOP N 待确认清单（供 Task 1.3 接续）

## 输入兼容

优先输入（自动衔接）：
- `dasheng-daily-intake` 运行产物中的 `intake-records.json`

兼容输入：
- `dasheng_v11_output_*.json`
- 任意符合 `phase2_rebuilder.py` 输入契约的 JSON

## 标准输出

默认输出到 run 目录下 `artifacts/phase2/`：

- `phase2-clusters-summary.json`
- `phase2-topic-index.json`
- `phase2-editorial-briefs.json`
- `phase2-brief-library.md`
- `phase2-topn-for-confirmation.json`
- `phase2-bitable-rows.json`
- `phase2-sync-contract.json`

## 执行方式

### 1）自动衔接 intake 最新 run

```bash
node ${OPENCLAW_WORKSPACE}/skills/dasheng-daily-phase2/index.js
```

### 2）指定 intake 文件

```bash
node ${OPENCLAW_WORKSPACE}/skills/dasheng-daily-phase2/index.js /path/to/intake-records.json
```

## 强化原则

- 不只给分组，要给编辑可执行建议。
- 每个话题簇必须给热度构成、证据链、标题建议与风险边界。
- 证据优先跨平台，避免单平台噪声主导。
- 输出必须可直接进入下游（Material Pack / 大纲）。
