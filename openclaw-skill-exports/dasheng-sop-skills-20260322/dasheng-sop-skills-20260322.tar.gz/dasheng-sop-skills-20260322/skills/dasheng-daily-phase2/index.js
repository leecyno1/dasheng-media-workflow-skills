#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const {
  nowIso,
  readJsonIfExists,
  writeJson,
  markStepCompleted,
  markStepFailed,
  updateManifest
} = require('../dasheng-daily-shared/runtime/manifest');
const { appendArtifactRef } = require('../dasheng-daily-shared/runtime/artifact-store');

const WORKSPACE = '${OPENCLAW_WORKSPACE}';
const RUNTIME_DIR = path.join(WORKSPACE, 'skills', 'dasheng-daily-shared', 'runtime-data');
const PHASE2_SCRIPT = path.join(WORKSPACE, 'scripts', 'phase2_rebuilder.py');
const TOPIC_SPEC_FILE = path.join(WORKSPACE, 'configs', 'phase2', 'topic_specs.v1.json');

function fileExists(file) {
  return !!file && fs.existsSync(file);
}

function discoverLatestIntakeArtifact() {
  const runsDir = path.join(RUNTIME_DIR, 'runs');
  if (!fs.existsSync(runsDir)) return null;

  const runIds = fs.readdirSync(runsDir).sort().reverse();
  for (const runId of runIds) {
    const manifestFile = path.join(runsDir, runId, 'run_manifest.json');
    const manifest = readJsonIfExists(manifestFile);
    if (!manifest) continue;

    const intake = (manifest.artifacts || []).find(
      item => item.step === 'intake' && item.object_type === 'IntakeRecord' && fileExists(item.file)
    );
    if (intake) {
      return { runId, intakeFile: intake.file, manifestFile, manifest };
    }
  }

  return null;
}

function inferRunIdFromFile(inputFile) {
  try {
    const data = JSON.parse(fs.readFileSync(inputFile, 'utf8'));
    const list = Array.isArray(data) ? data : data.items;
    const first = Array.isArray(list) && list.length ? list[0] : null;
    if (!first) return null;

    if (first.meta && first.meta.run_id) return first.meta.run_id;
    if (first.run_id) return first.run_id;
  } catch (e) {
    return null;
  }
  return null;
}

function runPhase2(inputFile, runId) {
  const outputDir = path.join(RUNTIME_DIR, 'runs', runId, 'artifacts', 'phase2');
  fs.mkdirSync(outputDir, { recursive: true });

  const args = [
    PHASE2_SCRIPT,
    inputFile,
    outputDir,
    '--topic-spec-file', TOPIC_SPEC_FILE,
    '--min-count', '1',
    '--max-clusters', '20',
    '--top-n', '3',
    '--run-id', runId,
    '--upstream-ref', path.basename(inputFile, '.json')
  ];

  const proc = spawnSync('python3', args, { encoding: 'utf8' });
  if (proc.status !== 0) {
    throw new Error(`phase2 执行失败\nSTDOUT:\n${proc.stdout}\nSTDERR:\n${proc.stderr}`);
  }

  const summaryFile = path.join(outputDir, 'phase2-clusters-summary.json');
  const briefFile = path.join(outputDir, 'phase2-brief-library.md');
  const editorialFile = path.join(outputDir, 'phase2-editorial-briefs.json');
  const topicIndexFile = path.join(outputDir, 'phase2-topic-index.json');
  const topNFile = path.join(outputDir, 'phase2-topn-for-confirmation.json');

  for (const file of [summaryFile, briefFile, editorialFile, topicIndexFile, topNFile]) {
    if (!fileExists(file)) throw new Error(`缺少 phase2 输出文件: ${file}`);
  }

  const summary = readJsonIfExists(summaryFile);

  return {
    outputDir,
    summaryFile,
    briefFile,
    editorialFile,
    topicIndexFile,
    topNFile,
    summary,
    stdout: proc.stdout
  };
}

function upsertManifest(manifest, files, stats) {
  let next = appendArtifactRef(manifest, {
    step: 'clustering',
    object_type: 'ClusteredTopic',
    count: stats.cluster_count || 0,
    file: files.summaryFile,
    doc_url: null
  });

  next = appendArtifactRef(next, {
    step: 'brief',
    object_type: 'ContentBrief',
    count: stats.cluster_count || 0,
    file: files.editorialFile,
    doc_url: null
  });

  next = appendArtifactRef(next, {
    step: 'brief',
    object_type: 'BriefMarkdown',
    count: 1,
    file: files.briefFile,
    doc_url: null
  });

  next = appendArtifactRef(next, {
    step: 'brief',
    object_type: 'TopicIndex',
    count: stats.cluster_count || 0,
    file: files.topicIndexFile,
    doc_url: null
  });

  next = markStepCompleted(next, 'clustering');
  next = markStepCompleted(next, 'brief');
  next = updateManifest(next, { current_step: 'material' });
  return next;
}

async function phase2(intakeFileArg, options = {}) {
  const startedAt = nowIso();
  let manifestFile = null;
  let manifest = null;

  try {
    let intakeFile = intakeFileArg || options.intake_records_file || options.input_file;
    let runId = options.run_id || null;

    if (!intakeFile) {
      const latest = discoverLatestIntakeArtifact();
      if (!latest) throw new Error('未找到可用 intake 产物，请先执行 dasheng-daily-intake');
      intakeFile = latest.intakeFile;
      runId = runId || latest.runId;
      manifestFile = latest.manifestFile;
      manifest = latest.manifest;
    }

    if (!fileExists(intakeFile)) {
      throw new Error(`intake 文件不存在: ${intakeFile}`);
    }

    runId = runId || inferRunIdFromFile(intakeFile) || `phase2-${startedAt.slice(0, 19).replace(/[-:T]/g, '')}`;
    manifestFile = manifestFile || path.join(RUNTIME_DIR, 'runs', runId, 'run_manifest.json');
    manifest = manifest || readJsonIfExists(manifestFile);

    const result = runPhase2(intakeFile, runId);
    const stats = (result.summary && result.summary.stats) || {};

    if (manifest) {
      const nextManifest = upsertManifest(manifest, result, stats);
      writeJson(manifestFile, nextManifest);
    }

    return {
      success: true,
      run_id: runId,
      intake_file: intakeFile,
      output_dir: result.outputDir,
      summary_file: result.summaryFile,
      brief_file: result.briefFile,
      editorial_file: result.editorialFile,
      topic_index_file: result.topicIndexFile,
      topn_file: result.topNFile,
      stats,
      next_step: 'dasheng-daily-material'
    };
  } catch (error) {
    if (manifest && manifestFile) {
      const nextManifest = markStepFailed(manifest, 'brief', error.message);
      writeJson(manifestFile, nextManifest);
    }
    throw error;
  }
}

if (require.main === module) {
  const intakeFile = process.argv[2];
  phase2(intakeFile)
    .then(result => {
      console.log(JSON.stringify(result, null, 2));
      process.exit(0);
    })
    .catch(err => {
      console.error(err.message);
      process.exit(1);
    });
}

module.exports = { phase2 };
