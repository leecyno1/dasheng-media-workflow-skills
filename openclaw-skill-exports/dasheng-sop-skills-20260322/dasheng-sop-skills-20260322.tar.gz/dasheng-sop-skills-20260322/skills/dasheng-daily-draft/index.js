#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const {
  nowIso,
  readJsonIfExists,
  writeJson,
  sha1,
  markStepCompleted,
  markStepFailed,
  finishManifest
} = require('../dasheng-daily-shared/runtime/manifest');
const {
  persistArtifact,
  appendArtifactRef
} = require('../dasheng-daily-shared/runtime/artifact-store');

const SHARED_DIR = path.join(__dirname, '..', 'dasheng-daily-shared');
const RUNTIME_DIR = path.join(SHARED_DIR, 'runtime-data');

async function generateDraft(outlinePlansFile, options = {}) {
  let manifest;
  let manifestFile;

  try {
    const plansFile = outlinePlansFile || options.outline_plans_file;
    if (!plansFile || !fs.existsSync(plansFile)) {
      throw new Error('缺少 outline_plans_file');
    }

    const outlines = JSON.parse(fs.readFileSync(plansFile, 'utf8'));
    const runId = options.run_id || outlines?.[0]?.meta?.run_id;
    if (!runId) throw new Error('无法从 OutlinePlan 推断 run_id');

    manifestFile = path.join(RUNTIME_DIR, 'runs', runId, 'run_manifest.json');
    manifest = readJsonIfExists(manifestFile);
    if (!manifest) throw new Error(`manifest 不存在: ${manifestFile}`);

    console.log(`[draft] 开始生成初稿 run_id=${runId}`);

    const drafts = outlines.map(outline => buildDraftPackage(outline, runId));
    const resultFile = persistArtifact({
      baseDir: RUNTIME_DIR,
      runId,
      step: 'draft',
      name: 'draft-packages.json',
      data: drafts
    });

    manifest = appendArtifactRef(manifest, {
      step: 'draft',
      object_type: 'DraftPackage',
      count: drafts.length,
      file: resultFile,
      doc_url: null
    });

    manifest = markStepCompleted(manifest, 'draft');
    manifest.current_step = 'final';
    manifest = finishManifest(manifest);
    writeJson(manifestFile, manifest);

    console.log(`[draft] 完成，共 ${drafts.length} 条初稿`);
    return {
      success: true,
      run_id: runId,
      total_drafts: drafts.length,
      draft_packages_file: resultFile,
      manifest_file: manifestFile,
      next_step: 'dasheng-daily-final'
    };
  } catch (error) {
    if (manifest && manifestFile) {
      manifest = markStepFailed(manifest, 'draft', error.message);
      writeJson(manifestFile, manifest);
    }
    console.error('[draft] 错误:', error.message);
    throw error;
  }
}

function buildDraftPackage(outline, runId) {
  const createdAt = nowIso();
  const content = generateDraftContent(outline);
  return {
    meta: {
      id: `${runId}:draft:${outline.meta.id.split(':').pop()}`,
      object_type: 'DraftPackage',
      run_id: runId,
      version: '3.0.0',
      status: 'ready',
      generated_by: 'dasheng-daily-draft',
      input_digest: sha1(outline.meta.id + outline.title),
      upstream_ids: [outline.meta.id],
      doc_refs: [],
      created_at: createdAt,
      updated_at: createdAt
    },
    topic_id: outline.topic_id,
    title: outline.title,
    style: outline.style || 'lemon_dna',
    content,
    word_count: content.length,
    sections_used: (outline.sections || []).map(s => s.title),
    draft_notes: [
      '基于 OutlinePlan 直接展开，尚未接入真实资料引用拼装',
      '后续 final 阶段负责复审和标题增强'
    ]
  };
}

function generateDraftContent(outline) {
  const sections = outline.sections || [];
  let content = `# ${outline.title}\n\n`;

  for (const section of sections) {
    content += `## ${section.title}\n\n${section.content}\n\n`;
    for (const subsection of section.subsections || []) {
      content += `### ${subsection.title}\n\n${subsection.content}\n\n`;
    }
  }

  return content.trim() + '\n';
}

if (require.main === module) {
  const outlinePlansFile = process.argv[2];
  generateDraft(outlinePlansFile).then(() => process.exit(0)).catch(() => process.exit(1));
}

module.exports = { generateDraft, buildDraftPackage, generateDraftContent };
