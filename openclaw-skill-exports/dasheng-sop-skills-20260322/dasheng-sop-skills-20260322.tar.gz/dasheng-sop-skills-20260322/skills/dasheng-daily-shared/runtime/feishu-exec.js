#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { buildSyncBridgeContract, syncFeishuDocs } = require('./runner');

function indexContractDocs(contract) {
  return Object.fromEntries((contract.docs || []).map(doc => [doc.key, doc]));
}

function getRunRoot(runId) {
  return path.join(__dirname, '..', 'runtime-data', 'runs', runId);
}

function getBridgeDir(runId) {
  return path.join(getRunRoot(runId), 'bridge');
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function writeJson(file, data) {
  ensureDir(path.dirname(file));
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
  return file;
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function createHandlersFromContract(contract, docMap = {}) {
  const contractDocs = indexContractDocs(contract);

  function pickDoc(key, fallbackTitle, content) {
    const mapped = docMap[key] || {};
    const planned = contractDocs[key] || {};
    if (!mapped.url) throw new Error(`缺少 ${key} 文档 URL`);
    return {
      title: mapped.title || planned.title || fallbackTitle,
      url: mapped.url,
      content
    };
  }

  return {
    createSummaryDoc: async ({ title, content }) => pickDoc('summary', title, content),
    createBriefDoc: async ({ title, content }) => pickDoc('brief', title, content),
    createFinalDoc: async ({ title, content }) => pickDoc('final', title, content),
    createPostmortemDoc: async ({ title, content }) => pickDoc('postmortem', title, content)
  };
}

function prepareFeishuSync(runId) {
  const contract = buildSyncBridgeContract(runId);
  const pendingDocs = (contract.docs || []).map(doc => ({
    key: doc.key,
    title: doc.title,
    content: doc.content,
    bind: doc.bind
  }));
  const bridgeDir = getBridgeDir(runId);
  const pendingFile = writeJson(path.join(bridgeDir, 'pending-docs.json'), {
    run_id: runId,
    pending_docs: pendingDocs
  });
  const contractFile = writeJson(path.join(bridgeDir, 'sync-contract.json'), contract);

  return {
    phase: 'prepare',
    run_id: runId,
    pending_docs_file: pendingFile,
    contract_file: contractFile,
    pending_docs: pendingDocs,
    contract
  };
}

async function finalizeFeishuSync(runId, docMap = {}) {
  const contract = buildSyncBridgeContract(runId);
  const handlers = createHandlersFromContract(contract, docMap);
  const result = await syncFeishuDocs(runId, handlers);
  return {
    phase: 'finalize',
    contract,
    sync_result: result
  };
}

async function finalizeFeishuSyncFromFile(runId, file) {
  const payload = readJson(file);
  const docs = payload.created_docs || payload.docs || {};
  return finalizeFeishuSync(runId, docs);
}

function parseDocMap(argv) {
  const docMap = {};
  for (const token of argv) {
    const [key, url] = token.split('=');
    if (!key || !url) continue;
    docMap[key] = { url };
  }
  return docMap;
}

function parseArgs(argv) {
  const args = { phase: 'prepare', runId: null, docArgs: [], fromFile: null };
  for (const token of argv) {
    if (token === '--prepare') args.phase = 'prepare';
    else if (token === '--finalize') args.phase = 'finalize';
    else if (token.startsWith('--finalize-from-file=')) {
      args.phase = 'finalize-from-file';
      args.fromFile = token.split('=')[1] || null;
    } else if (!args.runId) args.runId = token;
    else args.docArgs.push(token);
  }
  return args;
}

if (require.main === module) {
  const args = parseArgs(process.argv.slice(2));
  const runId = args.runId;
  if (!runId) {
    console.error('usage: node feishu-exec.js <runId> [--prepare|--finalize|--finalize-from-file=/path/to/created-docs.json] [summary=<url>] [brief=<url>] [final=<url>] [postmortem=<url>]');
    process.exit(1);
  }

  if (args.phase === 'prepare') {
    console.log(JSON.stringify(prepareFeishuSync(runId), null, 2));
    process.exit(0);
  }

  if (args.phase === 'finalize-from-file') {
    if (!args.fromFile) {
      console.error('[feishu-exec] 失败: 缺少 --finalize-from-file 路径');
      process.exit(1);
    }
    finalizeFeishuSyncFromFile(runId, args.fromFile).then(result => {
      console.log(JSON.stringify(result, null, 2));
      process.exit(0);
    }).catch(error => {
      console.error('[feishu-exec] 失败:', error.message);
      process.exit(1);
    });
    return;
  }

  const docMap = parseDocMap(args.docArgs);
  finalizeFeishuSync(runId, docMap).then(result => {
    console.log(JSON.stringify(result, null, 2));
    process.exit(0);
  }).catch(error => {
    console.error('[feishu-exec] 失败:', error.message);
    process.exit(1);
  });
}

module.exports = {
  createHandlersFromContract,
  prepareFeishuSync,
  finalizeFeishuSync,
  finalizeFeishuSyncFromFile,
  parseDocMap,
  parseArgs,
  getBridgeDir
};
