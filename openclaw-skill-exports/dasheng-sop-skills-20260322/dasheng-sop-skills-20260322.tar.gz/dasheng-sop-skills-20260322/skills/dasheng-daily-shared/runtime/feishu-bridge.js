#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { getBridgeDir } = require('./feishu-exec');

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function writeJson(file, data) {
  ensureDir(path.dirname(file));
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
  return file;
}

function getPendingDocsFile(runId) {
  return path.join(getBridgeDir(runId), 'pending-docs.json');
}

function getCreateRequestsFile(runId) {
  return path.join(getBridgeDir(runId), 'create-requests.json');
}

function getCreatedDocsFile(runId) {
  return path.join(getBridgeDir(runId), 'created-docs.json');
}

function buildCreateRequests(runId) {
  const pendingFile = getPendingDocsFile(runId);
  const payload = readJson(pendingFile);
  const requests = (payload.pending_docs || []).map(doc => ({
    key: doc.key,
    title: doc.title,
    content: doc.content,
    bind: doc.bind,
    status: 'pending_create'
  }));

  const output = {
    run_id: runId,
    source_file: pendingFile,
    requests
  };

  const outFile = writeJson(getCreateRequestsFile(runId), output);
  return { run_id: runId, create_requests_file: outFile, requests };
}

function materializeCreatedDocs(runId, sourceFile) {
  const payload = readJson(sourceFile);
  const requests = payload.requests || payload.pending_docs || [];
  const createdDocs = {};

  for (const item of requests) {
    if (!item.key) continue;
    if (!item.url) {
      throw new Error(`缺少 ${item.key} 的 url，无法生成 created-docs.json`);
    }
    createdDocs[item.key] = {
      url: item.url,
      title: item.title || null
    };
  }

  const output = {
    run_id: runId,
    created_docs: createdDocs
  };

  const outFile = writeJson(getCreatedDocsFile(runId), output);
  return { run_id: runId, created_docs_file: outFile, created_docs: createdDocs };
}

function parseArgs(argv) {
  const args = { action: 'prepare', runId: null, fromFile: null };
  for (const token of argv) {
    if (token === '--prepare-requests') args.action = 'prepare';
    else if (token.startsWith('--materialize-from=')) {
      args.action = 'materialize';
      args.fromFile = token.split('=')[1] || null;
    } else if (!args.runId) args.runId = token;
  }
  return args;
}

if (require.main === module) {
  const args = parseArgs(process.argv.slice(2));
  if (!args.runId) {
    console.error('usage: node feishu-bridge.js <runId> [--prepare-requests|--materialize-from=/path/to/file.json]');
    process.exit(1);
  }

  try {
    if (args.action === 'prepare') {
      console.log(JSON.stringify(buildCreateRequests(args.runId), null, 2));
      process.exit(0);
    }

    if (!args.fromFile) {
      throw new Error('缺少 --materialize-from 文件路径');
    }

    console.log(JSON.stringify(materializeCreatedDocs(args.runId, args.fromFile), null, 2));
    process.exit(0);
  } catch (error) {
    console.error('[feishu-bridge] 失败:', error.message);
    process.exit(1);
  }
}

module.exports = {
  getPendingDocsFile,
  getCreateRequestsFile,
  getCreatedDocsFile,
  buildCreateRequests,
  materializeCreatedDocs,
  parseArgs
};
