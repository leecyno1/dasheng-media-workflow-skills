#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { getBridgeDir } = require('./feishu-exec');

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function writeJson(file, data) {
  ensureDir(path.dirname(file));
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
  return file;
}

function getCreateRequestsFile(runId) {
  return path.join(getBridgeDir(runId), 'create-requests.json');
}

function getCreatedDocsFile(runId) {
  return path.join(getBridgeDir(runId), 'created-docs.json');
}

function buildTitleCandidates(key, title) {
  const candidates = [title].filter(Boolean);
  if (key === 'final') {
    candidates.push(
      title?.replace(/\s+-\s+/, ' ') || null,
      title?.replace(/v2/gi, '二版') || null,
      title?.replace(/Final/gi, 'Final 二版') || null,
      title?.replace(/dasheng-daily Final - (\d{4}-\d{2}-\d{2})/i, 'dasheng-daily Final $1 二版') || null,
      'dasheng-daily Final 2026-03-17 二版'
    );
  }
  if (key === 'summary') {
    candidates.push(`${title} v2`, `${title} 二版`);
  }
  if (key === 'brief' || key === 'postmortem') {
    candidates.push(`${title} v2`, `${title} 二版`);
  }
  return [...new Set(candidates.filter(Boolean))];
}

function prepareCreateJobs(runId) {
  const requestFile = getCreateRequestsFile(runId);
  const payload = readJson(requestFile);
  const jobs = (payload.requests || []).map(item => ({
    key: item.key,
    title: item.title,
    title_candidates: buildTitleCandidates(item.key, item.title),
    content: item.content,
    status: item.status || 'pending_create'
  }));
  return { run_id: runId, request_file: requestFile, jobs };
}

function applyCreatedDocs(runId, createdDocs) {
  const requestFile = getCreateRequestsFile(runId);
  const payload = readJson(requestFile);
  payload.requests = (payload.requests || []).map(item => {
    const created = createdDocs[item.key];
    if (!created?.url) return item;
    return {
      ...item,
      url: created.url,
      title: created.title || item.title,
      status: 'created'
    };
  });
  writeJson(requestFile, payload);
  return requestFile;
}

function materializeCreatedDocs(runId) {
  const requestFile = getCreateRequestsFile(runId);
  const payload = readJson(requestFile);
  const createdDocs = {};

  for (const item of payload.requests || []) {
    if (!item.key) continue;
    if (!item.url) throw new Error(`缺少 ${item.key} 的 url，无法生成 created-docs.json`);
    createdDocs[item.key] = {
      url: item.url,
      title: item.title || null
    };
  }

  const output = {
    run_id: runId,
    created_docs: createdDocs
  };

  const outFile = writeJson(getCreatedDocsFile(runId), output);
  return { run_id: runId, created_docs_file: outFile, created_docs: createdDocs };
}

function parseCreatedDocsFile(file) {
  const payload = readJson(file);
  return payload.created_docs || payload.docs || {};
}

function parseArgs(argv) {
  const args = { action: 'prepare-jobs', runId: null, fromFile: null };
  for (const token of argv) {
    if (token === '--prepare-jobs') args.action = 'prepare-jobs';
    else if (token.startsWith('--apply-created-docs=')) {
      args.action = 'apply-created-docs';
      args.fromFile = token.split('=')[1] || null;
    } else if (token === '--materialize-created-docs') {
      args.action = 'materialize-created-docs';
    } else if (!args.runId) args.runId = token;
  }
  return args;
}

if (require.main === module) {
  const args = parseArgs(process.argv.slice(2));
  if (!args.runId) {
    console.error('usage: node feishu-create-run.js <runId> [--prepare-jobs|--apply-created-docs=/path/to/file.json|--materialize-created-docs]');
    process.exit(1);
  }

  try {
    if (args.action === 'prepare-jobs') {
      console.log(JSON.stringify(prepareCreateJobs(args.runId), null, 2));
      process.exit(0);
    }

    if (args.action === 'apply-created-docs') {
      if (!args.fromFile) throw new Error('缺少 --apply-created-docs 文件路径');
      const createdDocs = parseCreatedDocsFile(args.fromFile);
      const requestFile = applyCreatedDocs(args.runId, createdDocs);
      console.log(JSON.stringify({ run_id: args.runId, request_file: requestFile, applied_keys: Object.keys(createdDocs) }, null, 2));
      process.exit(0);
    }

    console.log(JSON.stringify(materializeCreatedDocs(args.runId), null, 2));
    process.exit(0);
  } catch (error) {
    console.error('[feishu-create-run] 失败:', error.message);
    process.exit(1);
  }
}

module.exports = {
  buildTitleCandidates,
  prepareCreateJobs,
  applyCreatedDocs,
  materializeCreatedDocs,
  parseCreatedDocsFile,
  parseArgs
};
