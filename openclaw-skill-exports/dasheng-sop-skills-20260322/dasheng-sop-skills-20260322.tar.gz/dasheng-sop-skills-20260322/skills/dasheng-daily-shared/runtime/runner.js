#!/usr/bin/env node

const path = require('path');
const { makeRunId, runDateFromIso, nowIso, readJsonIfExists, writeJson, upsertArtifactDocUrl } = require('./manifest');
const { ensureManifest, getManifestFile, getPendingSteps, getStepInput, canRunStep } = require('./runner-core');
const {
  persistRunSummaryToFeishu,
  attachDocRefToObjects
} = require('./feishu-sync');
const { buildFeishuSyncPlan } = require('./feishu-plan');

const BASE_DIR = path.join(__dirname, '..', 'runtime-data');

const stepHandlers = {
  intake: require('../..//dasheng-daily-intake/index.js').intake,
  clustering: require('../..//dasheng-daily-clustering/index.js').clustering,
  brief: require('../..//dasheng-daily-brief/index.js').generateBrief,
  material: require('../..//dasheng-daily-material/index.js').supplementMaterial,
  outline: require('../..//dasheng-daily-outline/index.js').generateOutline,
  draft: require('../..//dasheng-daily-draft/index.js').generateDraft,
  final: require('../..//dasheng-daily-final/index.js').generateFinal,
  postmortem: require('../..//dasheng-daily-postmortem/index.js').generatePostmortem
};

async function runPipeline(options = {}) {
  const startedAt = nowIso();
  const runId = options.run_id || makeRunId('dasheng-daily', startedAt);
  const runDate = options.run_date || runDateFromIso(startedAt);

  ensureManifest(BASE_DIR, { runId, runDate });

  while (true) {
    const manifestFile = getManifestFile(BASE_DIR, runId);
    const manifest = readJsonIfExists(manifestFile);
    const pending = getPendingSteps(manifest);
    if (!pending.length) {
      return { success: true, run_id: runId, manifest_file: manifestFile, completed_steps: manifest.completed_steps || [] };
    }

    const nextStep = pending[0];
    if (!canRunStep(nextStep, manifest)) {
      throw new Error(`step ${nextStep} 缺少输入，无法继续`);
    }

    const handler = stepHandlers[nextStep];
    if (!handler) {
      throw new Error(`未注册 step handler: ${nextStep}`);
    }

    const input = getStepInput(nextStep, manifest);
    if (input) {
      await handler(input, { run_id: runId, run_date: runDate });
    } else {
      await handler({ run_id: runId, run_date: runDate });
    }
  }
}

function updateManifestDocUrl(runId, step, objectType, url) {
  const manifestFile = getManifestFile(BASE_DIR, runId);
  const manifest = readJsonIfExists(manifestFile);
  const updated = upsertArtifactDocUrl(manifest, step, objectType, url);
  writeJson(manifestFile, updated);
  return manifestFile;
}

function makeDocCreator(feishuClient, ownerOpenId) {
  return async ({ title, content }) => {
    const created = await feishuClient.create({ title, content, ownerOpenId });
    return {
      url: created.url,
      title: created.title,
      doc_token: created.doc_token
    };
  };
}

async function syncFeishuDocs(runId, handlers = {}) {
  const plan = buildFeishuSyncPlan(runId);
  const createdDocs = [];

  const createDoc = handlers.createDoc || null;
  if (!createDoc) {
    return {
      mode: 'tool-bridge-required',
      run_id: runId,
      manifest_file: plan.manifest_file,
      docs: Object.values(plan.docs).filter(Boolean).map(doc => ({
        key: doc.key,
        title: doc.title,
        content: doc.content,
        bind: doc.bind
      }))
    };
  }

  for (const doc of Object.values(plan.docs).filter(Boolean)) {
    const created = await createDoc({ key: doc.key, title: doc.title, content: doc.content, bind: doc.bind || null });
    createdDocs.push({ key: doc.key, title: created.title, url: created.url, doc_token: created.doc_token || null });

    if (doc.bind) {
      attachDocRefToObjects({
        file: doc.bind.file,
        objectType: doc.bind.object_type,
        url: created.url,
        title: created.title
      });
      updateManifestDocUrl(runId, doc.bind.step, doc.bind.object_type, created.url);
    }

    if (doc.key === 'summary') {
      await persistRunSummaryToFeishu({
        runId,
        feishuDocCreate: async () => created,
        title: doc.title,
        content: doc.content
      });
    }
  }

  const manifestFile = getManifestFile(BASE_DIR, runId);
  return { run_id: runId, manifest_file: manifestFile, created_docs: createdDocs };
}

function buildSyncBridgeContract(runId) {
  const plan = buildFeishuSyncPlan(runId);
  const docs = Object.values(plan.docs).filter(Boolean).map(doc => ({
    key: doc.key,
    title: doc.title,
    content: doc.content,
    bind: doc.bind
  }));

  return {
    mode: 'tool-bridge-required',
    run_id: runId,
    manifest_file: plan.manifest_file,
    docs
  };
}

function parseArgs(argv) {
  const args = { runId: null, syncFeishu: false };
  for (const token of argv) {
    if (token === '--sync-feishu') args.syncFeishu = true;
    else if (!args.runId) args.runId = token;
  }
  return args;
}

if (require.main === module) {
  const args = parseArgs(process.argv.slice(2));
  runPipeline({ run_id: args.runId || null }).then(result => {
    if (args.syncFeishu) {
      const contract = buildSyncBridgeContract(result.run_id);
      console.log(JSON.stringify({ ...result, sync_feishu: contract }, null, 2));
    } else {
      console.log(JSON.stringify(result, null, 2));
    }
    process.exit(0);
  }).catch(error => {
    console.error('[runner] 失败:', error.message);
    process.exit(1);
  });
}

module.exports = { runPipeline, syncFeishuDocs, updateManifestDocUrl, parseArgs, buildSyncBridgeContract, makeDocCreator };
