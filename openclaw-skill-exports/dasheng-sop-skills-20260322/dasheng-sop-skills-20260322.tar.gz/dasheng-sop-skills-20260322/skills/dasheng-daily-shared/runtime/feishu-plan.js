#!/usr/bin/env node

const path = require('path');
const { readJsonIfExists } = require('./manifest');
const {
  buildSummaryContent,
  buildBriefContent,
  buildFinalContent,
  buildPostmortemContent
} = require('./feishu-sync');

const BASE_DIR = path.join(__dirname, '..', 'runtime-data');

function buildFeishuSyncPlan(runId) {
  const runRoot = path.join(BASE_DIR, 'runs', runId);
  const manifestFile = path.join(runRoot, 'run_manifest.json');
  const manifest = readJsonIfExists(manifestFile);
  if (!manifest) throw new Error(`manifest 不存在: ${manifestFile}`);

  const briefFile = path.join(runRoot, 'artifacts', 'brief', 'content-briefs.json');
  const finalFile = path.join(runRoot, 'artifacts', 'final', 'final-packages.json');
  const postmortemFile = path.join(runRoot, 'artifacts', 'postmortem', 'postmortem-records.json');

  const briefs = readJsonIfExists(briefFile) || [];
  const finals = readJsonIfExists(finalFile) || [];
  const postmortem = readJsonIfExists(postmortemFile) || {};

  return {
    run_id: runId,
    run_date: manifest.run_date,
    manifest_file: manifestFile,
    docs: {
      summary: {
        key: 'summary',
        title: `dasheng-daily run ${manifest.run_date} 产物总览`,
        content: buildSummaryContent(manifest),
        bind: null
      },
      brief: briefs.length ? {
        key: 'brief',
        title: `dasheng-daily Brief - ${manifest.run_date}`,
        content: buildBriefContent(briefs),
        bind: {
          step: 'brief',
          object_type: 'ContentBrief',
          file: briefFile
        }
      } : null,
      final: finals.length ? {
        key: 'final',
        title: `dasheng-daily Final - ${manifest.run_date}`,
        content: buildFinalContent(finals),
        bind: {
          step: 'final',
          object_type: 'FinalPackage',
          file: finalFile
        }
      } : null,
      postmortem: postmortem.records?.length ? {
        key: 'postmortem',
        title: `dasheng-daily Postmortem - ${manifest.run_date}`,
        content: buildPostmortemContent(postmortem),
        bind: {
          step: 'postmortem',
          object_type: 'PostmortemRecord',
          file: postmortemFile
        }
      } : null
    }
  };
}

if (require.main === module) {
  const runId = process.argv[2];
  if (!runId) {
    console.error('usage: node feishu-plan.js <runId>');
    process.exit(1);
  }
  const plan = buildFeishuSyncPlan(runId);
  console.log(JSON.stringify(plan, null, 2));
}

module.exports = { buildFeishuSyncPlan };
