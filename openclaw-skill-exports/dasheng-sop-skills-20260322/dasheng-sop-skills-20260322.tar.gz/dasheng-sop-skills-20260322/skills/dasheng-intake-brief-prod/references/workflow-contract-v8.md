# Workflow Contract v8 (Domain-first Topic Clustering)

## Input

- Collector output: `intake-output-v11.json` (or equivalent `items[]` JSON)
- Phase2 engine: `scripts/phase2_rebuilder.py` (v8 mode)
- Domain config: `configs/phase2/domain_taxonomy.v8.json`

## Runtime Output Layout

`${OPENCLAW_WORKSPACE}/logs/daily-intake-YYYYMMDD-HHMMSS/phase2-prod-v8/`

Required artifacts:
- `phase2-domain-map.json`
- `phase2-topic-clusters.json`
- `phase2-cluster-audit.json`
- `phase2-brief-cards.md`
- `phase2-topn-for-confirmation.json`
- `phase2-rejects.json`
- `phase2-bitable-rows.json`
- `phase2-sync-contract.json`

## Processing Logic

1. Normalize + dedupe + noise filtering
2. Domain routing (soft assignment)
3. In-domain clustering
4. Cluster audit (purity/consistency/noise/platform-bias)
5. Split/merge and reject
6. Parent-child naming
7. Ranking with domain balance
8. Brief card generation

## Quality Gate (hard)

- Topic clusters count in `[10, 20]`
- Domain coverage `>= 6`
- Any single domain cluster share `<= 35%`
- Cluster evidence consistency `>= 0.70`
- Noise clusters not included in topn
- Parent-child duplication not shown as flat duplicates

## Brief Card Minimum Fields

- `parent_topic`
- `topic_cluster`
- `thesis`
- `why_now`
- `audience_value`
- `angles[]`
- `evidence_items[]` (3-5)
- `risk_notes[]`
- `next_actions[]`

## Review Publish Standard

When publishing to Feishu:
1. Create doc
2. Write `phase2-brief-cards.md`
3. Read back and verify `block_count > 1`
4. Return URL + revision_id + block_count + key stats

## Bitable Standard

Use `phase2-bitable-rows.json` as source for upsert by `object_id/topic_cluster`.
Do not sync unless user explicitly requests.

## Backward Compatibility

- Keep v7 artifacts for rollback
- v8 is new subdir `phase2-prod-v8`
- preserve previous CLI options where possible
