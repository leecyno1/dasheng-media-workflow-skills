---
name: dasheng-intake-brief-prod
description: Execute the reusable Dasheng production workflow for "rerun intake -> process ~1000-item draft in enhanced phase2 -> generate review-ready Brief library with evidence, heat analysis, and editorial suggestions". Use when users ask to rerun采集+第二环节、生成最新版Brief库、或复用同类选题生产流程。
---

# dasheng-intake-brief-prod

## Overview

Use this skill to run the stable production chain:
1) run or reuse latest intake data,
2) process all intake topics in v7 semantic clustering (dynamic topic discovery),
3) output detailed brief assets (heat/evidence/suggestions/risk/next-actions),
4) optionally publish markdown to Feishu for review.

## Workflow

### Step 1: Run pipeline

Default (rerun intake + phase2):

```bash
python3 ${OPENCLAW_WORKSPACE}/skills/dasheng-intake-brief-prod/scripts/run_pipeline.py
```

Reuse existing intake file:

```bash
python3 ${OPENCLAW_WORKSPACE}/skills/dasheng-intake-brief-prod/scripts/run_pipeline.py \
  --input-file ${OPENCLAW_WORKSPACE}/memory/dasheng_v11_output_YYYYMMDD_HHMMSS.json
```

Read JSON output and capture:
- `run_dir`
- `phase2_dir`
- `summary_file`
- `brief_file`
- `topn_file`
- `topic_index_file`
- `editorial_briefs_file`
- `stats`

### Step 2: Validate outputs

Must exist and be non-empty:
- `phase2-clusters-summary.json`
- `phase2-brief-library.md`
- `phase2-topn-for-confirmation.json`
- `phase2-topic-index.json`
- `phase2-editorial-briefs.json`

Surface key numbers:
- total input topics
- classified count
- unmatched count
- cluster count
- TOP topics with heat

### Step 3: Publish review doc (optional)

When user asks to review in Feishu:
1. `feishu_doc action=create` with title `YYYY-MM-DD 第二环节强化 Brief（最新审核版）`
2. `feishu_doc action=write` with `phase2-brief-library.md`
3. `feishu_doc action=read` and verify `block_count > 1`
4. return doc URL + revision_id + block_count

### Step 4: Optional Bitable sync

Only run when user explicitly requests.
Use `phase2-bitable-rows.json` with upsert strategy by `object_id/topic`.

## Output Contract

Always return:
- run id / run directory
- summary stats
- top topics + heat
- output file paths
- Feishu review doc URL (if created)
- next step: TOP3 confirmation -> Task 1.3 Material Pack

## Resources

- Pipeline runner: `scripts/run_pipeline.py`
- Data contract (v7): `references/workflow-contract.md`
- Data contract (v8 blueprint): `references/workflow-contract-v8.md`
- Architecture blueprint: `${OPENCLAW_WORKSPACE}/docs/phase2-v8-blueprint.md`
